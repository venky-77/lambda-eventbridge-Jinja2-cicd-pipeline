from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import os
java_home = os.environ.get("JAVA_HOME")
print(java_home)
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["PATH"] = os.environ["HADOOP_HOME"] + r"\bin;" + os.environ["PATH"]

# PKGS = ",".join([
#     "org.apache.hadoop:hadoop-aws:3.3.4",
#     "com.amazonaws:aws-java-sdk-bundle:1.12.262"
# ])

PKGS = "org.apache.hadoop:hadoop-aws:3.3.4,com.amazonaws:aws-java-sdk-bundle:1.12.367"

# Create Spark session
# spark = (
#     SparkSession.builder
#     .appName("pyspark_test")
#     .master("local[*]")
#     # === S3A + credentials provider ===
#     .config("spark.jars.packages", PKGS)
#     .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
#     .config("spark.hadoop.fs.s3a.aws.credentials.provider",
#             "com.amazonaws.auth.DefaultAWSCredentialsProviderChain")
#     # Optional: tune connections
#     .config("spark.hadoop.fs.s3a.connection.maximum", "200")
#     .getOrCreate()
# )
spark = (
    SparkSession.builder
    .appName("pyspark_test")
    .master("local[*]")
    .config("spark.jars.packages", PKGS)
    .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
    .config("spark.hadoop.fs.s3a.aws.credentials.provider",
            "com.amazonaws.auth.DefaultAWSCredentialsProviderChain")
    .config("spark.hadoop.fs.s3a.connection.maximum", "200")
    .getOrCreate()
)


print("Spark:", spark.version)
# (Optional) check Hadoop version actually loaded
print("Hadoop:", spark._jvm.org.apache.hadoop.util.VersionInfo.getVersion())
BUCKET_SRC = 's3a://batch89-pyspark-new/landing_zone/'

# Extract the data from s3
df = (spark.read
      .option("header", True)
      .option("inferSchema", True)
      .csv(BUCKET_SRC))
df.show()
# Tranformation
# df.drop("Model", "Model Variant", "Variant Title", "Available Colors")

#df = df.drop("votes",	"director",	"writer",	"star",	"country",	"budget", 	"gross", 	"company",	"runtime")
df.write.csv("s3a://batch89-pyspark-new/derived_zone/", header=True, mode="overwrite")
